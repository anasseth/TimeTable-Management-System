export class Student {
  id?: number;
  name?: string;
  email?: string;
  password?: string;
  group?: string;
}
