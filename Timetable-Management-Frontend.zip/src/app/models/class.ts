export class Class {
    id?: number;
    name?: string;
    room?: string;
    type?: string;
    description?: string;
}