export class Course {
    id?: number;
    name?: string;
    type?: string;
    description?: string;
}